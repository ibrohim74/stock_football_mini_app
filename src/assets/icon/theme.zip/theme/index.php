<?php
/*
Template Name: zip
*/
?>
<?php
$lang = "ru";
if (isset($_GET["lang"])) {
    $lang = $_GET["lang"];
}
$Language = parse_ini_file(get_template_directory() . "/language/$lang.ini");
?>
<?php get_header(); ?>
<div class="AppContent">
    <header>
        <div class="header_left">
            <div class="header_left_title_text wow animate__animated animate__fadeInLeft">
                <h1>Original zip</h1>
                <span></span>
            </div>
            <p class="wow animate__animated animate__fadeInLeft"><?php echo $Language["header_subtitle"] ?> </p>
            <div class="header_button wow animate__animated animate__fadeInLeft">
                <a href="#calc"><?php echo $Language["buy"] ?></a>
            </div>
        </div>
        <div class="header_right">
            <div class="swiper-container mySwiper ">
                <div class="swiper-wrapper">


                    <div class="swiper-slide">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/product/p2.png"/>
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/product/p10.png"/>
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/product/p5.png"/>
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/product/p6.png"/>
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/product/p7.png"/>
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/product/p8.png"/>
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/product/p9.png"/>
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/product/p1.png"/>
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/product/p13.png"/>
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/product/p14.png"/>
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/product/p15.png"/>
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/product/p16.png"/>
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/product/p17.png"/>
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/product/p18.png"/>
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/product/p4.png"/>
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/product/p3.png"/>
                    </div>
                </div>
                <!-- Swiper pagination qo'shildi -->

            </div>
            <div class="swiper-pagination"></div>
        </div>
    </header>

    <div class="container">
        <div class="partners">
            <div class="partners_text wow animate__animated animate__fadeInLeft">
                <div>
                    <h1><?php echo $Language["partners"]; ?></h1>
                    <span></span>
                </div>
                <h1><?php echo $Language["partners2"]; ?></h1>
            </div>
        </div>
        <div class="partners_content">
            <div class="partners_content_box">
                <img src="<?php bloginfo('template_url'); ?>/assets/img/logo.png" alt="Partner Logo">
            </div>
        </div>
    </div>


    <div class="container">
        <section class="about">
            <div class="about_box">
                <div class="header_left_title_text wow animate__animated animate__fadeInLeft">
                    <h1><?php echo $Language["company"] ?></h1>
                    <span></span>
                </div>
                <div class="about_title wow animate__animated animate__fadeInLeft">
                    <p><?php echo $Language["aboutP1"] ?></p>
                </div>
                <div class="about_text_box">
                    <div class="about_text_box_left wow animate__animated animate__fadeInLeft">
                        <p><?php echo $Language["aboutP2"] ?></p>
                        <p><?php echo $Language["aboutP3"] ?></p>
                        <p><?php echo $Language["aboutP4"] ?></p>
                    </div>
                    <div class="about_text_box_right wow animate__animated animate__fadeInRight">
                        <img src="<?php bloginfo('template_url') ?>/assets/img/icon/about_icon.png"
                             alt="О компании Original zip">
                    </div>
                </div>
                <div class="about_title_footer wow animate__animated animate__fadeInLeft">
                    <p><?php echo $Language["aboutP5"] ?></p>
                </div>
            </div>
        </section>

        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
             aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header text-black">
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body text-black" id="modalBody">

                    </div>
                    <div class="modal-footer d-flex justify-content-center align-items-center">
                        <a href="#contact" type="button" class="btn btn-primary">
                            <?php echo $Language["btn_modal"] ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>


        <section class="calc" id="calc">

            <div class="calc_box">
                <div class="header_left_title_text wow animate__animated animate__fadeInLeft">
                    <h1><?php echo $Language["calc_title"] ?>
                        <button type="button" id="tooltipButton" class="btn btn-secondary"
                                style="border-radius: 50% ; height: 30px ; width: 30px ; padding: 0; margin-left: 8px;"
                                data-bs-toggle="tooltip" data-bs-placement="bottom"
                                title="<?php echo $Language["calc_description"] ?>">
                            !
                        </button>
                    </h1>
                    <span style="margin-left: 20px"></span>
                </div>
                <form action="javascript:void(0);">
                    <div class="input-calc_top">
                        <div class="input-calc">
                            <label><?php echo $Language["sifat"] ?></label>
                            <select id="mikronSelect" name="mikron" onchange="showDescription()">
                                <option value="120" data-price="0.0262"
                                        data-description="<?php echo $Language["premium_desc"] ?>">
                                    <?php echo $Language["premium_title"] ?>
                                </option>
                                <option value="70" data-price="0.0131"
                                        data-description="<?php echo $Language["standard_desc"] ?>">
                                    <?php echo $Language["standard_title"] ?>
                                </option>
                                <option value="60" data-price="0.0082"
                                        data-description="<?php echo $Language["budjet_desc"] ?>">
                                    <?php echo $Language["budjet_title"] ?>
                                </option>
                            </select>

                            <div id="descriptionBox"></div>

                        </div>
                        <div class="input-calc">
                            <label><?php echo $Language["calc_shtuk"] ?></label>
                            <input type="tel" name="zakaz" id="zakazInput"/>
                        </div>

                    </div>
                    <div class="input-calc_top">

                        <div class="input-calc">
                            <label><?php echo $Language["eni"] ?></label>
                            <div class="input-wrapper">
                                <input type="tel" name="shirina" placeholder="0"/>
                                <span class="unit">mm</span>
                            </div>
                        </div>

                        <div class="input-calc">
                            <label><?php echo $Language["boyi"] ?></label>
                            <div class="input-wrapper">
                                <input type="tel" name="visota" placeholder="0"/>
                                <span class="unit">mm</span>
                            </div>
                        </div>


                    </div>
                    <div class="input-calc_bottom">
                        <div class="input-calc">
                            <label><?php echo $Language["kurs"] ?></label>
                            <input type="text" name="kurs" class="input_kurs" readonly/>
                            <p class="kurs_desc"><?php echo $Language["kurs_desc"] ?></p>
                        </div>
                        <div class="input-calc">
                            <button type="button"
                                    data-bs-toggle="modal" data-bs-target="#staticBackdrop"
                                    onclick="hisoblash()"><?php echo $Language["calc_button"] ?></button>
                        </div>
                    </div>
                </form>

                <div class="clac_actv" id="clac_actv"></div>

            </div>
        </section>


        <section class="fact">
            <div class="fact_box">
                <div class="header_left_title_text wow animate__animated animate__fadeInLeft">
                    <h1><?php echo $Language["fact"] ?></h1>
                    <span></span>
                </div>
                <h2 class="wow animate__animated animate__fadeInLeft"><?php echo $Language["fact_title"] ?></h2>
                <p class="wow animate__animated animate__fadeInLeft"><?php echo $Language["fact_desc"] ?></p>
            </div>
        </section>

        <section class="contact" id="contact">
            <div class="contact_box">
                <div class="contact_title  wow animate__animated animate__fadeInLeft">
                    <h1><?php echo $Language["contact_title"] ?></h1>
                    <div class="contact_subtitle wow animate__animated animate__fadeInLeft">
                        <h2><?php echo $Language["contact_title2"] ?></h2>
                        <span></span>
                    </div>
                </div>

                <form action="<?php bloginfo('template_url') ?>/telegram.php" method="POST" class="contact_form"
                      onsubmit="return validateForm()">
                    <div class="form_comment wow animate__animated animate__fadeInLeft">
                        <textarea id="comments" rows="10" cols="30" name="comment"></textarea>
                        <label for="comments" style="width: 100%"><?php echo $Language["comment"] ?></label>
                    </div>

                    <div class="form_comment form_col2 wow animate__animated animate__fadeInLeft">
                        <div class="input_FIO">
                            <input type="text" name="fio" required>
                            <label for="FIO"><?php echo $Language["fio"] ?></label>
                        </div>

                        <div class="input_box">
                            <div class="input_box_item">
                                <input type="text" name="company" required>
                                <label for="comments"><?php echo $Language["companyLabel"] ?></label>
                            </div>

                            <div class="input_box_item">
                                <input type="text" name="job" required>
                                <label for="comments"><?php echo $Language["job"] ?></label>
                            </div>
                        </div>
                    </div>

                    <div class="form_comment form_end wow animate__animated animate__fadeInRight">
                        <input type="text" name="phone" value="+998 " required oninput="phoneInput(event)"
                               onfocus="this.select()">
                        <label for="comments"><?php echo $Language["phone"] ?></label>
                        <button type="submit"><?php echo $Language["send"] ?></button>
                    </div>
                </form>
            </div>
        </section>
    </div>
</div>
<div class="footer_map">
    <iframe src="https://www.google.com/maps/embed?pb=!1m13!1m8!1m3!1d358.5037260499704!2d69.111528!3d41.313194!3m2!1i1024!2i768!4f13.1!3m2!1m1!2zNDHCsDE4JzQ3LjUiTiA2OcKwMDYnNDEuNSJF!5e1!3m2!1sru!2sus!4v1729159854790!5m2!1sru!2sus"
            width="70%" height="450" style="border-radius:20px; border: none" allowfullscreen="" loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"></iframe>

</div>
<footer>
    <div class="footer_top wow animate__animated animate__fadeInLeft">
        <a href="https://www.facebook.com/profile.php?id=61565000947813&mibextid=LQQJ4d"><img src="<?php bloginfo('template_url') ?>/assets/img/icon/facebook.png" alt=""></a>
        <a href="https://www.instagram.com/originalzipp?igsh=MXM4ZGRmdGZrdTFjNw=="><img
                    src="<?php bloginfo('template_url') ?>/assets/img/icon/instagram.png" alt=""></a>
        <a href="https://t.me/Originalzipp"><img src="<?php bloginfo('template_url') ?>/assets/img/icon/telegram.png" alt=""></a>
        <a href="https://api.whatsapp.com/qr/P4Z7MR5AT6JFA1?autoload=1&app_absent=0"><img src="<?php bloginfo('template_url') ?>/assets/img/icon/whatsapp.png" alt=""></a>
    </div>
    <div class="footer_bottom wow animate__animated animate__fadeInLeft">
        <a href="tel:+998900946968">+998(90)094-69-68</a>
        <a href="tel:+998901236968">+998(90)123-69-68</a>
    </div>
</footer>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const tooltipTriggerEl = document.getElementById('tooltipButton');
        const tooltip = new bootstrap.Tooltip(tooltipTriggerEl, {
            trigger: 'manual',
            boundary: 'window'
        });

        tooltipTriggerEl.addEventListener('click', function () {
            if (tooltip._element.getAttribute('aria-describedby')) {
                tooltip.hide();
            } else {
                tooltip.show();
            }
        });
    });

    function phoneInput(e) {
        const formattedValue = e.target.value.replace(/\D/g, ''); // Accept only numbers
        let formattedNumber = '+998';

        if (formattedValue.length > 3) {
            formattedNumber += ' ' + formattedValue.substring(3, 5);
        }
        if (formattedValue.length > 5) {
            formattedNumber += ' ' + formattedValue.substring(5, 8);
        }
        if (formattedValue.length > 8) {
            formattedNumber += ' ' + formattedValue.substring(8, 10);
        }
        if (formattedValue.length > 10) {
            formattedNumber += ' ' + formattedValue.substring(10, 12);
        }

        e.target.value = formattedNumber;
    }

    function validateForm() {
        const phoneInput = document.querySelector('input[name="phone"]');
        const phoneValue = phoneInput.value.replace(/\D/g, '');


        if (phoneValue.length !== 12) { // +998 + 9 digits
            alert('<?php echo $Language["error_tell"] ?>');
            return false;
        }

        return true;
    }
</script>

<script>

    document.getElementById('zakazInput').addEventListener('input', function (e) {
        let value = e.target.value.replace(/\s/g, '');
        let formattedValue = '';

        if (value) {

            formattedValue = Number(value.replace(/\D/g, '')).toLocaleString('ru-RU');
        }


        e.target.value = formattedValue;
    });
    async function getKurs() {
        try {

            let response = await fetch('https://api.exchangerate-api.com/v4/latest/USD');
            let data = await response.json();
            let kursUZS = data.rates.UZS;


            document.querySelector('input[name="kurs"]').value = `${kursUZS.toFixed(2)} = 1$`;
        } catch (error) {
            document.getElementById('modalBody').innerHTML = `<?php echo $Language["kurs_error"]?>`;
            console.error("Kursni olishda xatolik:", error);
        }
    }

    function showDescription() {
        var mikronSelect = document.getElementById("mikronSelect");
        var selectedOption = mikronSelect.options[mikronSelect.selectedIndex];
        var description = selectedOption.getAttribute("data-description");


        document.getElementById("descriptionBox").innerHTML = `<p>${description}</p>`;
    }


    document.addEventListener("DOMContentLoaded", function () {
        showDescription();
    });

    function hisoblash() {

        let zakaz = parseFloat(document.querySelector('input[name="zakaz"]').value.replace(/\s/g, '').replace(',', '.')); // zakaz soni
        let shirina = parseFloat(document.querySelector('input[name="shirina"]').value.replace(/\s/g, '').replace(',', '.')); // mm
        let visota = parseFloat(document.querySelector('input[name="visota"]').value.replace(/\s/g, '').replace(',', '.')); // mm
        let kurs = parseFloat(document.querySelector('input[name="kurs"]').value.replace(/\s/g, '').replace(',', '.')); // UZS dan USD ga aylantirish kursi
        var mikronSelect = document.getElementById("mikronSelect");
        var priceUZSString = mikronSelect.options[mikronSelect.selectedIndex].getAttribute("data-price"); // Narx UZS da mm² uchun

        var priceUZS = parseFloat(priceUZSString.replace(',', '.'));


        if (isNaN(zakaz) || isNaN(shirina) || isNaN(visota) || isNaN(kurs) || isNaN(priceUZS)) {
            document.getElementById('modalBody').innerHTML = `<?php echo $Language["clac_error"]?>`;
            return;
        }

        console.log("zakaz:", zakaz, "shirina:", shirina, "visota:", visota, "kurs:", kurs, "priceUZS:", priceUZS);

        let m2Shtuk = shirina * visota;
        console.log("m2Shtuk:", m2Shtuk);

        let pricePerItem = m2Shtuk * priceUZS;
        console.log("Price per item:", pricePerItem);
        let pricePerItemUSD = m2Shtuk * priceUZS / kurs;

        let totalPriceUZS = pricePerItem * zakaz;
        console.log("Total price UZS:", totalPriceUZS);

        let totalPriceUSD = totalPriceUZS / kurs;
        console.log("Total price USD:", totalPriceUSD);

        let formattedPriceUZS = totalPriceUZS.toLocaleString('uz-UZ', {
            style: 'decimal',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }) + " uzs";
        let formattedPriceItemUZS = pricePerItem.toLocaleString('uz-UZ', {
            style: 'decimal',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }) + " uzs";
        let formattedPriceUSD = totalPriceUSD.toLocaleString('en-US', {
            style: 'decimal',
            minimumFractionDigits: 3,
            maximumFractionDigits: 3
        });
        let formattedPriceItemUSD = pricePerItemUSD.toLocaleString('en-US', {
            style: 'decimal',
            minimumFractionDigits: 3,
            maximumFractionDigits: 3
        });

        document.getElementById('modalBody').innerHTML = `<p>
        <span><?php echo $Language["itemPrice"]?> : ${formattedPriceItemUZS} / $${formattedPriceItemUSD}</span> <br/>
        <?php echo $Language["clac_result"]?>: ${formattedPriceUZS}  / $${formattedPriceUSD}
     </p>`;
    }
    window.onload = getKurs;
</script>

<?php get_footer(); ?>
