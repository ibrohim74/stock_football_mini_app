    <?php
    wp_footer(); ?>


    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>


    <script>


        document.addEventListener('DOMContentLoaded', function () {
            const uzbekistanTime = new Date(); // Mahalliy vaqtni olish
            const bomdodTime = new Date(uzbekistanTime.getFullYear(), uzbekistanTime.getMonth(), uzbekistanTime.getDate(), 5, 0);
            const shomTime = new Date(uzbekistanTime.getFullYear(), uzbekistanTime.getMonth(), uzbekistanTime.getDate(), 18, 0);

            if (uzbekistanTime >= bomdodTime && uzbekistanTime < shomTime) {
                document.body.classList.add('day-mode'); // Kunduzgi rejim
                document.body.classList.remove('night-mode');
            } else {
                document.body.classList.add('night-mode'); // Tungi rejim
                document.body.classList.remove('day-mode');
            }
        });
    </script>


    <script type="application/javascript">
        const matchMedia = window.matchMedia("(max-width:800px)")

        if (matchMedia.matches) {
            new Swiper(".mySwiper", {
                effect: 'coverflow',
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
                grabCursor: true,
                centeredSlides: true,
                slidesPerView: 2.5,  // Slayderning to'liq ko'rinishi uchun 2.5 qiymati
                coverflowEffect: {
                    rotate: 0,
                    stretch: 80,
                    depth: 200,
                    modifier: 1,
                    slideShadows: false,
                },
                loop: true,  // Loopni to'g'ri ishlatish uchun true qiymati
                spaceBetween: 5,  // Slayderlar orasidagi bo'shliq

                autoplay: {
                    delay: 1500,
                    disableOnInteraction: false,
                },
            });

        } else {
            new Swiper(".mySwiper", {
                spaceBetween: 30,
                effect: "fade",
                fadeEffect: {crossFade: true},
                loop: true,
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,

                },
                autoplay: true
            });
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-element-bundle.min.js"></script>
    </body>
    </html>