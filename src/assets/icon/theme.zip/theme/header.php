
<html lang="en">
<head>
    <meta name="google" content="notranslate">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1 , height=device-height">
    <title>Original zip</title>
    <link rel="stylesheet" href="<?php bloginfo('template_url') ?>/assets/css/index.css?ver=3.3.0">
    <link
            rel="stylesheet"
            href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"
    />
    <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
    />
    <script src="<?php bloginfo('template_url') ?>/js/wow.min.js"></script>
    <script>
        new WOW().init();
    </script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

    <?php wp_head(); ?>
</head>
<body>

<div class="lang_box">
    <div class="lang_view">
        <?php
        if (isset($_GET["lang"]) && $_GET["lang"] === "ru") {
            echo '<img src="' . get_template_directory_uri() . '/assets/img/icon/uz.svg" alt="Uzbek Flag">';

        } else {
            echo '<img src="' . get_template_directory_uri() . '/assets/img/icon/ru.svg" alt="Russian Flag">';
        }
        ?>
    </div>
    <div class="lang_link">
        <a href="?lang=ru"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icon/ru.svg" alt="Russian"></a>
        <a href="?lang=uz"><img src="<?php echo get_template_directory_uri(); ?>/assets/img/icon/uz.svg" alt="Uzbek"></a>
    </div>
</div>
